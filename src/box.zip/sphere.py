class Sphere:
   #member variables
   rad = 0

   #constructor

   def __init__(self,rad):
      self.rad = rad
      
    #member method
      def calcVolume(self): 
       vol = 4/3*3.14*rad**2
       return vol

      def calcSurfaceArea(self):
        surfArea= 4*3.14*rad**2
        return surfArea