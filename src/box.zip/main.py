#intoduction
print('Welcome to shape maker! Lets find and volume and surface area for a few shapes...')
print('Lets start with a box')
boxw= (input('width:'))
boxl= (input('length:'))
boxh= (input('height:'))


#import box statement
from box import Box

#instantiate box
myBox= Box(boxl,boxw,boxh)


#Print calc from Box
print('This is Volume:',myBox.calcVolume())
print('This is SurfaceArea:',myBox.calcSurfaceArea())

#start sphere info and gget user input
print('Next is the sphere')
rad=(input('radius:'))

#import sphere statement
from sphere import Sphere

#instantiate Sphere
mySphere = Sphere(rad)

#Print calc from Sphere
print('This is Volume:',mySphere.calcVolume())
print('This is SurfaceArea:',mySphere.calcSurfaceArea())

#pyramid get user inputs
print('The last shape is pyramid')
pyramidw= (input('width:'))
pyramidl= (input('length:'))
pyramidh= (input('height:'))

#import oyramdid statement
from pyramid import Pyramid

#instantiate Pyramid
myPyramid = Pyramid(pyramidw,pyramidl,pyramidh)

#Print calc from Pyramid
print('This is Volume:',myPyramid.calcVolume())
print('This is SurfaceArea:',myPyramid.calcSurfaceArea())



