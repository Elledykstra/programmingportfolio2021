class Box:
   #member variables
   l=0
   w=0
   h = 0

   #constructor

   def __init__(self, l, w, h):
      self.l = l
      self.w = w
      self.h = h
      
    #member method
      def calcVolume(self): 
       vol = self.l*self.w*self.h
       return vol

      def calcSurfaceArea(self):
        surfArea= 2*l*w+2*l*h+2*w*h
        return surfArea