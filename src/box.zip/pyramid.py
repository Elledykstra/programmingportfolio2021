class Pyramid:
   #member variables
   l=0
   w=0
   h = 0

   #constructor

   def __init__(self, l, w, h):
      self.l = l
      self.w = w
      self.h = h
      
    #member method
      def calcVolume(self): 
       vol = self.l*self.w*self.h/3
       return vol

      def calcSurfaceArea(self):
        surfArea= l*w+l/(w/2)**2+h**2+w/(l/2)**2+h**2
        return surfArea